from googletrans import Translator

translator = Translator()

def translate_text(text: str, target_lang: str) -> str:
    if not text:
        return ""
    try:
        result = translator.translate(str(text), dest=target_lang)
        return result.text
    except Exception as e:
        print(f"Translation error: {e}")
        return str(text)

def translate_internship(internship: dict, target_lang: str) -> dict:
    translated = internship.copy()
    translated["title"] = translate_text(internship.get("title", ""), target_lang)
    translated["sector"] = translate_text(internship.get("sector", ""), target_lang)
    translated["location"] = translate_text(internship.get("location", ""), target_lang)
    translated["skills_required"] = [
        translate_text(skill, target_lang) for skill in internship.get("skills_required", [])
    ]
    return translated
